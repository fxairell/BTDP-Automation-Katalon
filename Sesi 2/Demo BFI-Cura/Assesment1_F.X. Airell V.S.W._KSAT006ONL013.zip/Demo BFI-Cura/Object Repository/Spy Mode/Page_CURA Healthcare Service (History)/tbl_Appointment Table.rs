<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>tbl_Appointment Table</name>
   <tag></tag>
   <elementGuidId>01c85939-aa2e-4a61-975e-c1ed53181894</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='history']/div/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>449d9efd-1647-45bf-988a-05ea1a3e3410</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>row</value>
      <webElementGuid>b68c75e1-95a6-4118-93f3-d33cbeceddc3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        
                
                    06/07/2022
                    
                        
                            Facility
                        
                        
                            Tokyo CURA Healthcare Center
                        
                        

                        
                            Apply for hospital readmission
                        
                        
                            No
                        
                        

                        
                            Healthcare Program
                        
                        
                            Medicare
                        
                        

                        
                            Comment
                        
                        
                            
                        
                    
                
            
                    </value>
      <webElementGuid>c9b52641-f382-4bd4-8b56-0411e691665b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;history&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]</value>
      <webElementGuid>4628c78d-d777-4e12-95bb-8ca06f53ca06</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='history']/div/div[2]</value>
      <webElementGuid>e8f4c3d8-79b4-4f29-9546-79636b561d6b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='History'])[2]/following::div[1]</value>
      <webElementGuid>0b65e335-bdc2-48d4-926e-bd84cad3c2aa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Make Appointment'])[1]/following::div[4]</value>
      <webElementGuid>4c0e8085-caea-43b4-ade4-366008521651</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]</value>
      <webElementGuid>277fb78e-28b3-4c1c-b823-171ba0ac1613</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                        
                
                    06/07/2022
                    
                        
                            Facility
                        
                        
                            Tokyo CURA Healthcare Center
                        
                        

                        
                            Apply for hospital readmission
                        
                        
                            No
                        
                        

                        
                            Healthcare Program
                        
                        
                            Medicare
                        
                        

                        
                            Comment
                        
                        
                            
                        
                    
                
            
                    ' or . = '
                        
                
                    06/07/2022
                    
                        
                            Facility
                        
                        
                            Tokyo CURA Healthcare Center
                        
                        

                        
                            Apply for hospital readmission
                        
                        
                            No
                        
                        

                        
                            Healthcare Program
                        
                        
                            Medicare
                        
                        

                        
                            Comment
                        
                        
                            
                        
                    
                
            
                    ')]</value>
      <webElementGuid>4cd23838-5ad3-4fd0-8a78-1ef9a7401eb2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
